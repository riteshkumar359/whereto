<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Validation\Validation;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ApisController extends AppController
{

    public function initialize() {
        parent::initialize();

        $this->loadModel('Users');
        $this->loadModel('tempusers');
        

    }

    public function beforeFilter(Event $event){
        
    $this->Auth->Allow(['requestotp','verifyotp','login']);
        
    }

    // Request Otp For Signup
    public function requestotp()
    {

       
        $tempUser = $this->tempusers->newEntity();
        if ($this->request->is('post')) {

       $requestdata= $this->request->input('json_decode');
      
       $adddata['email']=$requestdata->email;
       $adddata['password']=$requestdata->password;
       $adddata['user_type_id']=$requestdata->role;
       $adddata['phone']=$requestdata->phone;
       $adddata['name']=$requestdata->name; 

       $userExists=$this->Users->find()->where(['email'=>$adddata['email']])->orwhere(['phone'=>$adddata['phone']])->first();

       

       if(empty($userExists))
       {

             $otp = rand(1000,9999);
             $adddata['otp']=$otp; 

           $to='+91'.$adddata['phone'];
            // ritesh 
           $from='+12402490164';
            //$from='+12143607444 ';
           $body='Your Onekliq signup Pin is ' .$otp.'.Please enter on Onekliq App to complete verification ';
           $sendmessage=$this->sendTwilloSms($to, $from, $body);

           $sendmessage=json_decode($sendmessage);
           $sendmessage=(array)$sendmessage;
           //debug($sendmessage);

           if($sendmessage['status']!=400)
           {
                 $tempUser = $this->tempusers->patchEntity($tempUser, $adddata);
                    if ($result=$this->tempusers->save($tempUser)) {
                        $insertId=$result->id;
                       $message = array(
                        "status"=> true,
                        "msg"=>"OTP has been sent to the entered username",
                        "data"=>array('userId'=> $insertId)
                        );

                        
                    }else{

                         $message = array(
                        "status"=> false,
                        "msg"=>"There was an error in sending otp"
                        );
                    }

           }
           else{
                 
                $message = array(
                "status"=> false,
                "message"=>$sendmessage['message']
               
                );
           }
    }
    else
    {
            $message = array(
                "status"=> false,
                "msg"=>"user already exists"
                );

    }
            
            echo json_encode($message);
        }


        
        die;
    }



    public function verifyotp()
    {
        if ($this->request->is('post')) {
         $requestdata= $this->request->input('json_decode');
         $userId=$requestdata->userId;
         $otp=$requestdata->otp;

         $tempUser = $this->tempusers->find()->where(['id'=>$userId,'otp'=>$otp])->first();
         
         if(!empty($tempUser))
         {
           
            $userData['name']=$tempUser['name'];
            $userData['email']=$tempUser['email'];
            $userData['phone']=$tempUser['phone'];
            $userData['username']=$tempUser['phone'];
            $userData['password']=$tempUser['password'];
            $userData['user_type_id']=$tempUser['user_type_id'];

            $userExists=$this->Users->find()->where(['email'=>$userData['email']])->orwhere(['phone'=>$userData['phone']])->first();

            if(empty($userExists))
            {

            $user=$this->Users->newEntity();
            $user=$this->Users->patchEntity($user,$userData);
            

            if($this->Users->save($user))
            {
               $message = array(
                "status"=> true,
                "msg"=>"Congratulations! You have been registered successfully!"
                ); 
            }
            else{
                 $message = array(
                "status"=> false,
                "msg"=>"There was an error in registered"
                ); 

            }
            } else{
                 $message = array(
                "status"=> false,
                "msg"=>"You have already registered"
                ); 

            }

         }
         else{
             $message = array(
                "status"=> false,
                "msg"=>"You have entered wrong otp"
                );
         }
         echo json_encode($message);
     }
         die;
         
    }

         public function login()
            {
            if ($this->request->is('post')) {

                $loginUserName=$this->request->data['username'];

                $userExists=$this->Users->find()->where(['email'=>$loginUserName])->orwhere(['phone'=>$loginUserName])->first();

               

            if(!empty($userExists))
            {

                if (Validation::email($this->request->data['username'])) {
                    $this->Auth->config('authenticate', [
                        'Form' => [
                            'fields' => ['username' => 'email']
                        ]
                    ]);
                    $this->Auth->constructAuthenticate();
                    $this->request->data['email'] = $this->request->data['username'];
                    unset($this->request->data['username']);
                }

                $user = $this->Auth->identify();

                if ($user) {
                    $this->Auth->setUser($user);
                    //debug($user);
                    $data['userId']=$user['id'];
                    $data['name']=$user['name'];
                    $data['email']=$user['email'];
                    $data['phone']=$user['phone'];
                    $data['role']=$user['user_type_id'];

                     $message = array(
                "status"=> true,
                "msg"=>"You have successfully login",
                "userData"=> $data
                );

                    
                }else{
                     $message = array(
                "status"=> false,
                "msg"=>" Password is incorrect"
                );
                }


            }else{

                 $message = array(
                "status"=> false,
                "msg"=>"User does not exists"
                );
                }
            }

                echo json_encode($message);

               die; 
            }
            
       

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $user = $this->Users->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $userTypes = $this->Users->UserTypes->find('list', ['limit' => 200]);
        $this->set(compact('user', 'userTypes'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }


        


    public function logout()
    {
        return $this->redirect($this->Auth->logout());
    }



     function sendTwilloSms($to, $from, $body) {
    
            $sid = 'ACb623be3c24ebed78b4ef1f369a84f43d';
            $token = '5a8f419d6ecd8eaf569bc3527a03e3b7';
            $uri = 'https://api.twilio.com/2010-04-01/Accounts/' . $sid . '/SMS/Messages.json';
            $auth = $sid . ':' . $token;
         
            // post string (phone number format= +15554443333 ), case matters
            $fields = 
                '&To=' .  urlencode( $to ) . 
                '&From=' . urlencode( $from ) . 
                '&Body=' . urlencode( $body );
         
            // start cURL
            $res = curl_init();
             
            // set cURL options
            curl_setopt( $res, CURLOPT_URL, $uri );
            curl_setopt( $res, CURLOPT_POST, 3 ); // number of fields
            curl_setopt( $res, CURLOPT_POSTFIELDS, $fields );
            curl_setopt( $res, CURLOPT_USERPWD, $auth ); // authenticate
            curl_setopt( $res, CURLOPT_RETURNTRANSFER, true ); // don't echo
             
            // send cURL
            $result = curl_exec( $res );
            return $result;
        }
}
